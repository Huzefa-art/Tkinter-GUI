#!/usr/bin/env python
# coding: utf-8

# In[54]:


from tkinter import Tk, Text, TOP, BOTH, X, N, LEFT, StringVar, OptionMenu, RIGHT,Y,BOTTOM,CENTER,END
from tkinter.ttk import Frame, Label, Entry, Style,Combobox,Spinbox, Button
import re
import datetime 
import time
import os
from threading import *
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.action_chains import ActionChains
from selenium import webdriver
from webdriver_manager.chrome import ChromeDriverManager
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait


#import threading

#from tkinter import *
#from tkinter.ttk import *
class AutoWAT(Frame):

    def __init__(self):
        super().__init__()
        
        #self.threads()
        self.initUI()
        Thread(target=self.whatsappinit).start()
        


    def initUI(self):
        

        self.master.title("AutoWhaT")
        self.pack(fill=BOTH, expand=True)
        
        style = Style()
        style.configure("frame1.TLabel")
        style.configure("frame2.TLabel")
        style.configure("frame3.TLabel")
        style.configure("frame4.TLabel")
        style.configure("frame5.TLabel")
        style.configure('W.TButton', font =('calibri', 10, 'bold'),foreground = 'red',width=15)
        style.configure("frame6.TLabel")

        frame1 = Frame(self,style="frame1.TLabel")
        frame1['padding'] = (5,15,5,10)

        # phone number widget
        frame1.pack(fill=X)

        Phone_no_lbl = Label(frame1, text="Contact info", width=15, font=("Helvetica",10))
        Phone_no_lbl.pack(side=LEFT)
        
        valid_phone_num = (self.register(self.validate_phone_num), '%P')
        invalid_phone_num = (self.register(self.on_invalid_phone_num,))
        self.label_error = Label(frame1, foreground='red')
        self.label_error.pack(side=RIGHT)
        
        self.num_var = StringVar()
        self.phone_no_txt_box = Entry(frame1,textvariable=self.num_var)
        self.phone_no_txt_box.config(validate='focusout', validatecommand=valid_phone_num, invalidcommand=invalid_phone_num)
            
        self.phone_no_txt_box.pack(fill=X,side =LEFT,expand =True)
        

        # drop down
        #options = ["Phone Number", "Group Name"]
        #clicked = StringVar()
        #clicked.set( "Phone Number" )
        #drop = OptionMenu(frame1 , clicked , *options )
        #drop.pack(side=RIGHT,padx =5)
        self.selected_contact = StringVar(frame1)        
        self.selected_contact.set( "Phone No" )
        


        self.contact_cb = Combobox(frame1, textvariable=self.selected_contact)
        self.contact_cb['values'] = ["Phone No", "Group Name"]
        self.contact_cb['state'] = 'readonly'
        self.contact_cb.pack(side=RIGHT,padx =5)
        
        if self.selected_contact.get() == "Phone No":
            self.num_var.set("911234567890")
            
        if self.selected_contact.get() == "Group Name":
            self.num_var.set("The Squad")

        # Message box widget

        frame2 = Frame(self,style="frame2.TLabel")
        frame2['padding'] = (5,15,5,10)
        frame2.pack(fill=X)

        Messagelbl = Label(frame2, text="Message", width=15)
        Messagelbl.pack(side=LEFT, padx=5, pady=5)

        self.Message_txtbox = Text(frame2, height = 5)
        self.Message_txtbox.insert(END,"Type Your Message Here")
        self.Message_txtbox.pack(fill=BOTH, padx=5, expand=True)
        
        # Timer widget

        frame3 = Frame(self,style="frame3.TLabel")
        frame3['padding'] = (5,15,5,10)
        frame3.pack(fill=X)

        Time_interval_lbl = Label(frame3, text="Time Interval", width=15)
        Time_interval_lbl.pack(side=LEFT, anchor=N, padx=5, pady=5)
        
        #hrs_txt_box = Entry(frame3)
        #hrs_txt_box.pack(fill=X,side =LEFT,expand =True)
        
        self.hrsvalue = StringVar()
        self.hrs = Spinbox(
            frame3,
            from_=0,
            to=60,
            values=(0, 10, 20, 30, 40, 50, 60),
            textvariable=self.hrsvalue,
            wrap=True,width = 15
        )

        self.hrsvalue.set("hrs")
        self.hrs.pack(side =LEFT,padx=5)
        
        self.minsvalue = StringVar()
        self.mins = Spinbox(
            frame3,
            from_=0,
            to=60,
            values=(0, 10, 20, 30, 40, 50, 60),
            textvariable=self.minsvalue,
            wrap=True,width = 15
        )
        self.minsvalue.set("mins")
        self.mins.pack(side =LEFT,padx=5)
        
        self.secsvalue = StringVar()
        self.secs = Spinbox(
            frame3,
            from_=0,
            to=60,
            values=(0, 10, 20, 30, 40, 50, 60),
            textvariable=self.secsvalue,
            wrap=True,width = 15
        )
        self.secsvalue.set("secs")
        self.secs.pack(side =LEFT,padx=5)
        #mins_txt_box = Entry(frame3)
        #mins_txt_box.pack(fill=X,side =LEFT,expand =True)
        #secs_txt_box = Entry(frame3)
        #secs_txt_box.pack(fill=X,side =LEFT,expand =True)
        
        # Message Count widget
        
        frame4 = Frame(self,style="frame4.TLabel")
        frame4['padding'] = (5,15,5,10)
        frame4.pack(fill=X)
        
        Message_count_lbl = Label(frame4, text="Message Count", width=15)
        Message_count_lbl.pack(side=LEFT, anchor=N, padx=5, pady=5)
        
        self.current_value = StringVar(frame4)
        val = [0, 10, 20, 30, 40, 50, 60,70,80,90,100]
        #current_value.set("Message Count")
        Message_count_spinbox = Spinbox(
            frame4,
            from_=0,
            to=100,
            values= val,
            textvariable=self.current_value,
            width = 20
        )
        
        
        Message_count_spinbox.pack(side =LEFT)
              
        # stop button widget
        stopbtn =Button(frame4,text="Stop",style = 'W.TButton', command= self.stoptimer)
        stopbtn.pack(side=LEFT,padx = 55)
        

        #Total_message_txt_box = Entry(frame4,width =30)
        #Total_message_txt_box.pack(side =LEFT)
        
        #start Button widget
        frame5 = Frame(self,style="frame5.TLabel")
        frame5['padding'] = (5,15,5,10)
        frame5.pack(fill=X)
        startbtn =Button(frame5,text="GO",width=20,command =self.threading)
        startbtn.pack()
        #openbrowserbtn = Button(frame5,text="Open Whatsapp")
        #openbrowserbtn.pack(side=LEFT)
        # status widget
        frame6 = Frame(self,style="frame6.TLabel")
        frame6['padding'] = (5,15,5,10)
        frame6.pack(fill=X)
        self.statuslbl = Label(frame6, text="Please wait for the browser to load")
        self.statuslbl.config(foreground="brown",font=("Helvetica",9,))
        self.statuslbl.pack(anchor=CENTER)
        #timerlbl
        self.timerlbl = Label(frame6, text="Click go to start the timer")
        self.timerlbl.config(foreground="brown",font=("Helvetica",9,))
        self.timerlbl.pack(anchor=CENTER)
        #self.whatsappinit()
    def show_message(self, error='', color='black'):
        self.label_error['text'] = error
        self.phone_no_txt_box['foreground'] = color

    def validate_phone_num(self, value):
        #pattern = r'\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'
        if self.selected_contact.get() == "Phone No" :
            pattern = r'[\d]{12}'
            if re.fullmatch(pattern, value) is None:
                return False
        self.show_message()
        return True

    def on_invalid_phone_num(self):
        if self.selected_contact.get() == "Phone No" :
            self.show_message('Please enter a valid phone number', 'red')
            
          
    def whatsappinit(self):
        #finding users chrome data path
        datapath = os.getenv('APPDATA').replace("\\Roaming", "")
        filepath = ""+datapath+r"\Local\Google\Chrome\User Data\Default"
        Chrome_data_path = r"user-data-dir="+filepath+""
        global driver
        self.statuslbl['text'] = 'Please Wait for chrome to start'
        driver = None
        chrome_options = webdriver.ChromeOptions()
        chrome_options.add_argument(Chrome_data_path)
        if not driver:
            #url ="https://web.whatsapp.com/send?phone=+92 3310374180"
            url ="https://web.whatsapp.com/"
            
        
            driver = webdriver.Chrome(options=chrome_options,service=Service(ChromeDriverManager().install()))
            driver.get(url)
            time.sleep(10)
    def stoptimer(self):
        self.total_sec = 0
        
    def threading(self):
        # Call work function
        timerrthread=Thread(target=self.timerr)
        timerrthread.start()
    def sendmessage(self,message):
        #url ="https://web.whatsapp.com/send?phone=+"+self.num_var.get()+""
        
        try:
            type_it = driver.find_elements(By.CLASS_NAME,'_13NKt')
            type_it[1].send_keys(message + Keys.ENTER)
            
        except IndexError as e:
            time.sleep(5) 
            type_it = driver.find_element(By.XPATH,'/html/body/div[1]/div[1]/div[1]/div[4]/div[1]/footer/div[1]/div/span[2]/div/div[2]/div[1]/div/div[2]')
            type_it.send_keys(message+ Keys.ENTER)
            
    def timerr(self):
        self.statuslbl['text'] = "Your timer is started"
        if self.selected_contact.get() == "Phone No" :
            url ="https://web.whatsapp.com/send?phone=+"+self.num_var.get()+""
            driver.get(url)
            self.total_sec = int(self.current_value.get()) *Time_interval 
            
        else:
            try:
                type_it = driver.find_elements(By.CLASS_NAME,'_13NKt')
                type_it[0].send_keys(self.num_var.get())
                group=driver.find_element(By.XPATH,"//div[@class='zoWT4']/span/span")
                #group_name =group.text
                group.click()
                self.total_sec = int(self.current_value.get()) *Time_interval 
            except:
                self.total_sec = 0
                self.statuslbl['text'] = "Given group Not found"
                
                
        
        i=0
        message =str(self.Message_txtbox.get("1.0",'end-1c'))
        Time_interval = int(self.hrsvalue.get()) * 3600 + int(self.minsvalue.get()) * 60 + int(self.secsvalue.get())
        
        sendmsgtime = int(self.current_value.get()) *Time_interval -Time_interval
        def sendmessage():
 
            try:
                type_it = driver.find_elements(By.CLASS_NAME,'_13NKt')
                type_it[1].send_keys(message + Keys.ENTER)
            except IndexError as e:
                time.sleep(5) 
                type_it = driver.find_element(By.XPATH,'/html/body/div[1]/div[1]/div[1]/div[4]/div[1]/footer/div[1]/div/span[2]/div/div[2]/div[1]/div/div[2]')
                type_it.send_keys(message+ Keys.ENTER)
                
        while self.total_sec > 0:
            timer = datetime.timedelta(seconds = self.total_sec)
            #print(timer, end="\r")
            self.timerlbl['text'] = timer
            #self.statuslbl['text'] = timer
            #global label
            #label["text"]= timer
            
            time.sleep(1)
            self.total_sec -= 1
            if(self.total_sec == sendmsgtime):
                sendmsgtime = sendmsgtime -Time_interval
                i+=1
                sendmessage()                    
                self.statuslbl['text'] = ""+str(i)+" Message sent"
                
                #self.statuslbl['text'] = '"'+str(i)+'"Message sent'
                #print("'"+str(i)+"'sent", end ="\r")
                #self.statuslbl['text'] = "Bzzzt! The countdown is at zero seconds!"
        #print("Bzzzt! The countdown is at zero seconds!")
        self.statuslbl['text'] = ""+str(i)+" Message sent \n The Timer is Ended"



        
    

def main():
    root = Tk()
    root.geometry("500x400+400+100")
    app = AutoWAT()
    root.mainloop()


if __name__ == '__main__':
    main()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




